# Eye Meds Final Build Summary

- built_at: 2026-07-14T00:27:28+08:00
- source_core_folder: C:\Users\liaow\OneDrive\文件\GitHub\pteduimg\data\eye_meds_rebuild_20260711\core
- source_enrichment_folder: C:\Users\liaow\OneDrive\文件\GitHub\pteduimg\data\eye_meds_rebuild_20260711\enrichment
- output_folder: C:\Users\liaow\OneDrive\文件\GitHub\pteduimg\data\eye_meds_rebuild_20260711\final
- products: 492
- substances: 204
- product_substances: 1353
- indications: 14
- product_indications: 586
- sources: 1371
- manual_review_queue: 496

## Outputs
- products.csv
- substances.csv
- product_substances.csv
- indications.csv
- product_indications.csv
- sources.csv
- manual_review_queue.csv
- eye_meds_final.json
- data_quality_report.md
- final_build_summary.md
