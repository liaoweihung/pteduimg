# Eye Meds Final Data Quality Report

- built_at: 2026-07-14T00:27:28+08:00
- products: 492
- JSON products: 492
- duplicate licenses: 0
- empty licenses: 0
- products missing substance relation: 0
- products missing indication relation: 0
- products missing source relation: 0
- confirmed active ingredient products: 449
- only unknown ingredient products: 24
- no ingredient relation products: 0
- indication raw completeness: 492/492
- dosage completeness: 492/492
- class completeness: 492/492
- license year completeness: 492/492
- conflict count: 0
- manual review count: 496
- substance role counts: {'active': 804, 'surfactant': 6, 'preservative': 154, 'tonicity_agent': 85, 'unknown': 70, 'buffer': 88, 'ph_adjuster': 22, 'vehicle': 46, 'ointment_base': 31, 'antioxidant': 5, 'viscosity_agent': 15, 'chelator': 14, 'other_excipient': 13}
- leaflet status counts: {'leaflet_unavailable': 426, 'available': 66}

## Conflict Handling
- Core product identity fields were retained unless enrichment had stronger confirmed evidence. No confirmed enrichment product-identity replacement was applied.
- OCR candidate values were not upgraded to confirmed.
- Unknown substance roles remain in the manual review queue.
